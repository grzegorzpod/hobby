
	Generator sekwencji dla portu szeregowego ver. 1.0 dla Win32
=========================================================================	

	� Grzegorz Podg�rski
	grzegorz.podgorski@wp.pl
	http://www.w.cz.prv.pl



1. Do czego to s�u�y?
========================
Program sekwencyjnie zmienia poziomy logiczne na trzech wyjsciach portu szeregowego.


2. Korzystanie z programu - zasada dzia�ania.
=================================================
Po uruchomieniu programu w pierwszej kolejnosci trzeba zdefiniowac stan trzech wyjsc (3 kolumny liczac od prawej) oraz czas w ms, przez ktory ten stan ma sie pojawic (pierwsza kolumna od lewej). Wartosc liczbowa czasu wprowadzamy przy pomocy klawiszy 0..9 natomiast stan wybranego wejscia przy pomocy "SPACJI" - puste pole jest rownoznaczne ze stanem niskim.
Zaznaczenie CheckBox'a "Petla" powoduje, ze sekwencja bedzie powtarzana az do nacisniencia przycisku ekranowego "STOP". Warto wiedziec, ze z przycisku tego mozna skorzystac w dowolnej chwili generowania sekwencji. Przycisk "START" rozpoczyna generowanie sekwencji. Przycisk "ZAPISZ" zapisuje zdefiniowana sekwencje, natomiast przycisk "WCZYTAJ" odczytuje sekwencje z pliku zapisana przez "ZAPISZ".


3. Troche danych technicznych.
=================================
Minimalny czas trwania jednego kroku - 10ms. Przy podawaniu mniejszych wartosci np. 0 czas kroku zalezy od szybkosci komputera i cechuje go duza niedokladnosc.
Pojemnosc tabeli - 32768 wierszy (w zupelnosci wystarczajaca)


4. Przykladowe zastosowanie - sterowanie wartoscia napiecia od -10 do +10V ze "schodkiem" co 2.5V na prostym przetworniku CA:
============================

Schemat przetwornika CA:

RTS o-------/\/\/\/\/\___o__/\/\/\/\/\-------> GND
			 |
 			| |
			| | R
			| |
		2R	 |
DTR o-------/\/\/\/\/\___O
			 |
 			| |
			| | R
			| |
		2R	 |
TxD o-------/\/\/\/\/\___O
			 |
 			| |
			| | R
			| |
			 |________0 wyjscie analogowe

GND o-----------------------------0

Wartosci R i 2R powinny byc przynajmniej rzedu kilkudziesieciu kOhm, tak aby pominac wplyw rezystancji wewnetrznej portu.


5. Warunki uzytkowania.
=======================
Program jest darmowy i mozesz go uzywac jak dlugo tylko chcesz. Jesli jestes zainteresowany kodem zrodlowym skontaktuj sie ze mna.


6. Uk�ad wyprowadze� portu RS232C w PC (cyferki s� napisane na wtyczkach).
=============================================================================
Uk�ad wyprowadze� portu:

DB25 DB9 Sygna� Opis Funkcja 

1    -   GND Chassis Ground masa 
2    3   TxD Transmit Data wyj�cie 
3    2   RxD Receive Data wej�cie 
4    7   RTS Request to Send wyj�cie 
5    8   CTS Clear to Send wej�cie 
6    6   DSR Data Set Ready wej�cie 
7    5   GND Signal Ground masa 
8    1   DCD Carrier Detect wej�cie 
20   4   DTR Data Terminal Ready wyj�cie 
22   9   RI Ring Indicator wej�cie 
