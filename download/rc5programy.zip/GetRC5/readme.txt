GetRC5 v1.0 - dekoder RC5


(C) Grzegorz Podgorski
email: grzegorz.podgorski@wp.pl
www:   http://www.w.cz.prv.pl

=================================


Zadaniem programu jest dekodowanie rozkaz�w pochodzacych z pilota RC5 odbieranych przy pomocy przystawki "IgorPlug", ktorej schemat zostal zamieszczony w pliku igorplug.gif .

WYMAGANIA
============
Program byl testowany na komputerze z procesorem celeron 433MHz pod kontrola systemu win2k. Za minimalne wymagania mozna przyjac procesor P166 i system win95, ale na wolniejszym sprzecie programowi trudniej jest bezblednie rozpoznac kod.

INSTRUKCJA UZYTKOWANIA
=======================
Po uruchomieniu programu trzeba dokonac wyboru portu i nacisnac przycisk "start".

WARUNKI UZYTKOWANIA
=====================
Program jest dostepny na zasadach Freeware tzn. mozesz go uzywac przez czas nieokreslony. Jesli jestes zainteresowany kodem zrodlowym (Delphi5.0) lub modyfikacjami "na zyczenie" skontaktuj sie ze mna.