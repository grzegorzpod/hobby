
	RC5SENDER v.1.0 


(C) Grzegorz Podgorski
email: grzegorz.podgorski@wp.pl
www:   http://www.w.cz.prv.pl

=================================

Program sluzy do generowania i emisji rozkazow w kodzie RC-5. Program jest "komputerowym pilotem",wykorzystujacym przystawke do transmisji modulowanej podczerwieni, ktorej schemat zawarty jest w pliku ir_nad.bmp . 

ZASTOSOWANIE
=============
- sterowanie sprzetem RTV przy pomocy komputera
- sprawdzanie odbiornikow podczerwieni i dekoderow RC-5

WYMAGANIA
===========
Program byl testowany na komputerze celeron 433MHz w pod systemem win 2k.

INSTRUKCJA UZYTKOWANIA
=======================
Po uruchomieniu programu trzeba wypelnic trzy kolumny:

-nazwe (dowolna lub mozna ja pominac),
-adres (patrz plik kodrc5.txt),
-komende (patrz plik kodrc5.txt),

oraz okreslic port, do ktorego podpieta jest przystawka.

Od tej pory po przejsciu do trybu sterowania (przelacznik w pozycji "1") mozna wywolywac zdefiniowany wczesniej rozkaz wskazujac kursorem myszy komorke z nazwa i naciskajac lewy przycisk. W przypadku trzymania klawisza myszy dluzej niz 100ms rozkaz jest powtarzany do momentu puszczenia klawisza. Uwaga: klikniecie mysza musi byc pojedyncze i trwac conajmniej 100ms.

WARUNKI UZYTKOWANIA
=====================
Program jest dostepny na zasadach Freeware tzn. mozesz go uzywac przez czas nieokreslony. Jesli jestes zainteresowany kodem zrodlowym (Delphi5.0) lub modyfikacjami "na zyczenie" skontaktuj sie ze mna.