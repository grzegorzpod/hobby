IRMon v1.0


(C) Grzegorz Podgorski
email: grzegorz.podgorski@wp.pl
www:   http://www.w.cz.prv.pl

=================================


Zadaniem programu jest prezentowanie paczek IR nadawanych przez piloty RTV a odbieranych przy pomocy przystawki "IgorPlug", ktorej schemat zostal zamieszczony w pliku igorplug.gif .


ZASTOSOWANIE
=============
- rejestrowanie sygnalow pochodzacych z pilotow

WYMAGANIA
============
Program byl testowany na komputerze z procesorem celeron 433MHz pod kontrola systemu win2k. 

INSTRUKCJA UZYTKOWANIA
=======================
Po uruchomieniu programu trzeba dokonac wyboru portu i nacisnac przycisk "start".
Wobec wykresu sa mozliwe nastepujace operacje:

ZOOM: Lewy przycisk myszy;
PRZEWIJANIE: Prawy przycisk myszy.

Wykres rysowany czerwona linia to wykres bierzacy.
Wykres rysowany zielona linia to wykres poprzedni.
Jesli wykresy sie pokrywaja to oznacza, ze odebrane dwie kolejne paczki sa identyczne.

WARUNKI UZYTKOWANIA
=====================
Program jest dostepny na zasadach Freeware tzn. mozesz go uzywac przez czas nieokreslony. Jesli jestes zainteresowany kodem zrodlowym (Delphi5.0) lub modyfikacjami "na zyczenie" skontaktuj sie ze mna.