DS1821 Programmer ver. 0.9 - Freeware


Przeznaczenie
----------------
Program wspomaga programowanie uk�adu DS1821, pe�ni�cego
funkcj� czujnika temperatury i cyfrowego termostatu.
Szczeg�y na temat uk�adu znajdziesz tutaj:
http://datasheets.maxim-ic.com/en/ds/DS1821.pdf

Schemat programatora znajduje si� w pliku "Programator DS1821.gif"



Obs�uga - zaprogramowanie czujnika
------------------------------------
1. Pod��czy� programator do PC a do programatora czujnik DS1821.
2. Uruchomic program i Wybra� port szeregowy, do kt�rego pod��czony
   jest programator.
3. Nacisn�� start - nast�pi prze��czenie w tryb programowania.
4. Okre�li� temperatury TL,TH.
5. Okre�li� bity T/R, POL, 1SHOT.
6. Wybra� przycisk "Zapisz ustawienia" - ustawienia zostan� wprowadzone
   do czujnika.
7. Uruchomi� ponownie program i zweryfikowa� ustawienia.

Przyk�ad ustawie�:
Czujnik ma pe�ni� funkcj� cyfrowego termostatu sygnalizuj�cego
przekroczenie temperatury 45st.C, histereza 1st.C
TR    -"v"
POL   -"v"
1SHOT -" "
Temp H - 45
Temp L - 44


Funkcje przycisk�w
-------------------
Panel ustawienia:
"START"-otwarcie portu
"STOP"-zamkni�cie portu
"O.."-informacja o programie
Panel temperatura - ostatnio odczytana temperatura
Panel termostat - temperatury okre�laj�ce p�tl� histerezy
Panel status - rejestr statusowy czujnika, pola wyszarzone s� tylko do
odczytu - szczeg�y w nocie katalogowej czujnika.
G��wne okno programu:
"Prze��cz w tryb 1-wire" - prze��cza czujnik w tryb programowania
"Wczytaj ustawienia" - odczytuje z czujnika aktualn� temp. oraz ustawienia
"Zapisz ustawienia" - zapisuje do pami�ci czujnika ustawienia


U�ytkowanie
-------------
Program jest rozpowszechniany na zasadach Freeware.


Kontakt z autorem
------------------
Grzegorz Podg�rski
email: grzegorz.podgorski@wp.pl
www: http://www.w.cz.prv.pl   http://grzesiek21.republika.pl