DS1065 Programmer ver. 0.9 - Freeware


Przeznaczenie
----------------
Program wspomaga programowanie uk�adu DS1065, pe�ni�cego
funkcj� generatora kwarcowego z preskalerem i podzielnikiem.
Szczeg�y na temat uk�adu znajdziesz tutaj:
http://datasheets.maxim-ic.com/en/ds/DS1065.pdf

Schemat programatora znajduje si� w pliku "DS1065Prog.gif"



Obs�uga - zaprogramowanie czujnika
------------------------------------
1. Pod��czy� programator do PC a do programatora czujnik DS1065.
2. Uruchomic program i Wybra� port szeregowy, do kt�rego pod��czony
   jest programator.
3. Nacisn�� start - nast�pi prze��czenie w tryb programowania.
4. Okre�li� ustawienia preskalera i podzielnika.
6. Wybra� przycisk "Zapisz" - ustawienia zostan� wprowadzone
   do czujnika.
7. Uruchomi� ponownie program i zweryfikowa� ustawienia.


Funkcje przycisk�w
-------------------
Panel ustawienia:
"START"-otwarcie portu
"STOP"-zamkni�cie portu
"O.."-informacja o programie
"Czytaj" - odczytuje z pami�ci czujnika ustawienia
"Zapisz" - zapisuje do pami�ci czujnika ustawienia


U�ytkowanie
-------------
Program jest rozpowszechniany na zasadach Freeware.


Kontakt z autorem
------------------
Grzegorz Podg�rski
email: grzegorz.podgorski@wp.pl
www: http://www.w.cz.prv.pl   http://grzesiek21.republika.pl