MINITERMO wersja 0.9 - DOKUMENTACJA

O PROGRAMIE
------------
Program MiniTermo jest komputerowym termometrem odczytujacym
temperature z czujnika DS1820 lub DS18B20 za pomoca adaptera
DS9097E. Schemat adaptera oraz uklad wyprowadze� czujnika zosta�y
do��czone w oddzielnych plikach.
Temperatura udostepniania jest:
-w trayu (obok windowsowego zegara)
-w okienku programu
-przez DDE

OBS�UGA
--------
Pierwsze uruchomienie programu s�u�y ustawieniu portu. Domy�lnie
program otwiera port com1. Je�li adapter pod��czony jest do innego
portu okre�l go a nast�pnie uruchom ponownie program.
Menu programu uaktywnia si� po najechaniu mysz� na jego ikonk� w trayu
i nacisni�ciu prawego przycisku. Lewy przycisk przywo�uje okno ustawie�.
Opr�cz okna ustawie� program wyposa�ono w panel prezentuj�cy temp.
kt�rego rozmiary i po�o�enie mo�na dowolnie okre�la�. Klikni�cie w
polu panela zamienia go w zwyk�e przemieszczalne okno windowsa,
ponowne klikni�cie blokuje okno.
Z my�l� o wsp�pracy oprogramowaniem wizualizacyjnym np.
LabView program wyposa�ono w funkcj� udost�pniania temp. innym aplikacjom
przez DDE.
Parametry dla klientow DDE:
SERVICE: MINITERMO
TOPIC: MINITERMO
ITEM: SENSOR
Poprawno�� ��cza DDE naj�atwiej sprawdzi� w programie MS-Excel wpisuj�c do
dowolnej kom�rki formu��:
=MINITERMO|MINITERMO!SENSOR
(zobacz pomoc w Excelu na temat DDE).


WARUNKI UZYTKOWANIA
--------------------
Program jest darmowy i rozpowszechniany na zasadach Freeware.


AUTOR
-------
Grzegorz Podg�rski
grzegorz.podgorski@wp.pl
http://www.w.cz.prv.pl

